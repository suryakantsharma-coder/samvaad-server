// /**
//  * Emergency vs normal case flow for the hospital voice agent.
//  * After language lock (Hindi / Gujarati only), caller is asked case type;
//  * emergency path reads DB number digit-by-digit in English, then repeat/note loop.
//  */

// /** @typedef {'awaiting_language'|'awaiting_case_type'|'emergency'|'emergency_ending'|'booking'} CallFlowPhase */

// const DIGIT_WORDS_EN = [
//   "zero",
//   "one",
//   "two",
//   "three",
//   "four",
//   "five",
//   "six",
//   "seven",
//   "eight",
//   "nine",
// ];

// const EMERGENCY_RE =
//   /\b(emergency|emerjency|imergency|urgent|aapatkal|aapat|आपात|इमरजेंसी|इमर्जेंसी|एमर्जेंसी|एमर्जन्सी|इमर्जन्सी)\b|ઇમરજન્સી|ઈમરજન્સી|આપત્તિ|आपातकाल|emergency\s*case|इमरजेंसी\s*केस/i;

// const NORMAL_RE =
//   /\b(normal|routine|regular|appointment|booking|opd)\b|सामान्य|नॉर्मल|रूटीन|अपॉइंटमेंट|बुकिंग|સામાન્ય|નોર્મલ|રૂટીન|એપોઇન્ટમેન્ટ|normal\s*case|सामान्य\s*केस/i;

// const NOTED_RE =
//   /note|not\s*kar|नोट|नोंध|likh|लिख|le liya|ले लिया|kar liya|kar liya hai|कर लिया|likh liya|लिख लिया|note kiya|not kiya|ho gaya|mil gaya|samajh|જ લીધ|નોંધ|લખ/i;

// const REPEAT_RE =
//   /repeat|dubara|dohbara|dobara|phir se|फिर से|दोबारा|farithi|ફરી|bol do|boliye|bolo|बोल|repeat kar|farithi bol/i;

// function sleep(ms) {
//   return new Promise((resolve) => setTimeout(resolve, ms));
// }

// /**
//  * @param {string} raw
//  * @returns {string[]}
//  */
// function extractEmergencyDigits(raw) {
//   const digits = String(raw || "").replace(/\D/g, "");
//   if (!digits) return [];
//   return digits.split("");
// }

// /** Emergency digits are always spoken in English (nine, eight, seven…). */
// function digitToWord(digitChar) {
//   const n = Number(digitChar);
//   if (Number.isFinite(n) && n >= 0 && n <= 9) return DIGIT_WORDS_EN[n];
//   return digitChar;
// }

// /** @param {'hi'|'gu'} lang */
// function langLabel(lang) {
//   return lang === "gu" ? "Gujarati" : "Hindi";
// }

// /** @param {'hi'|'gu'} lang */
// function buildCaseTypeQuestion(lang) {
//   if (lang === "gu") {
//     return "કૃપા કરીને જણાવો — આ કઈ રીતનો કેસ છે: ઇમરજન્સી કે સામાન્ય?";
//   }
//   return "कृपया बताइए — यह इमरजेंसी केस है या सामान्य केस?";
// }

// /** @param {'hi'|'gu'} lang */
// function getAskRepeatOrNotedLine(lang) {
//   if (lang === "gu") {
//     return "શું હું નંબર ફરી બોલું, કે તમે નોંધી લીધું છે?";
//   }
//   return "क्या मैं नंबर दोबारा बोलूँ, या आपने नोट कर लिया है?";
// }

// /**
//  * @param {'hi'|'gu'} lang
//  * @param {string} hospitalName
//  */
// function getEmergencyIntro(lang, hospitalName) {
//   const name = hospitalName || "अस्पताल";
//   if (lang === "gu") {
//     return `કૃપા કરીને ધ્યાનથી સાંભળો. ${name} નો ઇમરજન્સી નંબર છે:`;
//   }
//   return `कृपया ध्यान से सुनिए। ${name} का इमरजेंसी नंबर है:`;
// }

// /**
//  * @param {'hi'|'gu'} lang
//  * @param {string} hospitalName
//  */
// function getEmergencyThankYou(lang, hospitalName) {
//   const name = hospitalName || "अस्पताल";
//   if (lang === "gu") {
//     return `${name} માં ફોન કરવા બદલ આભાર.`;
//   }
//   return `${name} में फ़ोन करने के लिए धन्यवाद।`;
// }

// /**
//  * @param {string} text
//  * @returns {'emergency'|'normal'|null}
//  */
// function detectCaseType(text) {
//   const s = String(text || "").trim();
//   if (!s || s.length > 200) return null;
//   if (EMERGENCY_RE.test(s)) return "emergency";
//   if (NORMAL_RE.test(s)) return "normal";
//   return null;
// }

// /**
//  * @param {string} rawUser
//  * @param {string} normalizedUser
//  * @returns {'noted'|'repeat'|null}
//  */
// function detectRepeatOrNoted(rawUser, normalizedUser) {
//   const s = String(rawUser || "").trim();
//   if (!s) return null;
//   if (NOTED_RE.test(s)) return "noted";
//   if (REPEAT_RE.test(s)) return "repeat";

//   const {
//     isAffirmativeTurn,
//     isNegationTurn,
//   } = require("./userTranscriptNormalize");
//   if (isNegationTurn(rawUser, normalizedUser)) return "repeat";
//   if (isAffirmativeTurn(rawUser, normalizedUser)) return "noted";
//   return null;
// }

// /**
//  * @param {import("@livekit/agents").voice.AgentSession | null | undefined} session
//  */
// function pauseEmergencyRealtimeReplies(session) {
//   if (!session || typeof session.pauseReplyAuthorization !== "function") return;
//   try {
//     session.pauseReplyAuthorization();
//   } catch (_) {
//     /* ignore */
//   }
// }

// /**
//  * @param {import("@livekit/agents").voice.AgentSession | null | undefined} session
//  */
// function resumeEmergencyRealtimeForSpeech(session) {
//   if (!session || typeof session.resumeReplyAuthorization !== "function") return;
//   try {
//     session.resumeReplyAuthorization();
//   } catch (_) {
//     /* ignore */
//   }
// }

// /** @param {import("./agent").HospitalVoiceAgent | null | undefined} agent */
// function isEmergencySpeechPhase(agent) {
//   const cf = agent && agent.callFlow;
//   if (!cf) return false;
//   return (
//     cf.phase === "emergency" ||
//     cf.phase === "emergency_ending" ||
//     Boolean(cf.emergencyLlmActive) ||
//     Boolean(cf.emergencyScriptActive)
//   );
// }

// /**
//  * @param {import("./agent").HospitalVoiceAgent} agent
//  * @param {import("@livekit/agents").voice.AgentSession | null | undefined} session
//  */
// function lockEmergencyRealtimeReplies(agent, session) {
//   if (!agent || !agent.callFlow) return;
//   agent.callFlow.emergencyLlmActive = true;
//   pauseEmergencyRealtimeReplies(session);
// }

// /** @param {import("./agent").HospitalVoiceAgent | null | undefined} agent */
// function shouldKeepRealtimeReplyPaused(agent) {
//   const cf = agent && agent.callFlow;
//   if (!cf) return false;
//   return (
//     cf.phase === "awaiting_language" ||
//     cf.phase === "awaiting_case_type" ||
//     cf.phase === "emergency" ||
//     cf.phase === "emergency_ending" ||
//     Boolean(cf.emergencyLlmActive) ||
//     Boolean(cf.emergencyScriptActive)
//   );
// }

// /** Serialize programmatic Realtime speech so responses do not collide. */
// let programmaticSpeechChain = Promise.resolve();

// /**
//  * @param {import("@livekit/agents").voice.AgentSession | null | undefined} session
//  * @param {string} instructions
//  * @param {import("./agent").HospitalVoiceAgent | null | undefined} [agent]
//  */
// async function speakInstructionsOnce(session, instructions, agent) {
//   if (!session || typeof session.generateReply !== "function") return;
//   if (session.closing) return;

//   resumeEmergencyRealtimeForSpeech(session);

//   if (typeof session.interrupt === "function") {
//     try {
//       await session.interrupt({ force: true });
//     } catch (_) {
//       /* ignore */
//     }
//   }

//   try {
//     const { waitForStableAgentIdle } = require("./endCall");
//     await waitForStableAgentIdle(session, 500);
//   } catch (_) {
//     /* ignore */
//   }

//   if (session.closing) return;

//   const emergency = isEmergencySpeechPhase(agent);
//   const emergencyGuard = emergency
//     ? " EMERGENCY MODE ONLY — do NOT ask about symptoms, disease, doctors, appointments, or booking. Say ONLY the requested line and stop."
//     : "";

//   let handle;
//   try {
//     handle = session.generateReply({
//       toolChoice: "none",
//       instructions: `${instructions}${emergencyGuard}`,
//     });
//   } catch (err) {
//     const msg = err && err.message ? err.message : String(err);
//     console.error("[CallFlow] speakInstructions generateReply failed:", msg);
//     if (shouldKeepRealtimeReplyPaused(agent)) pauseEmergencyRealtimeReplies(session);
//     return;
//   }

//   if (handle && typeof handle.waitForPlayout === "function") {
//     try {
//       await handle.waitForPlayout();
//     } catch (err) {
//       const msg = err && err.message ? err.message : String(err);
//       console.warn("[CallFlow] speakInstructions waitForPlayout:", msg);
//     }
//   }

//   if (shouldKeepRealtimeReplyPaused(agent)) {
//     pauseEmergencyRealtimeReplies(session);
//   }
// }

// async function speakInstructions(session, instructions, agent) {
//   programmaticSpeechChain = programmaticSpeechChain
//     .then(() => speakInstructionsOnce(session, instructions, agent))
//     .catch((err) => {
//       const msg = err && err.message ? err.message : String(err);
//       console.error("[CallFlow] speakInstructions chain error:", msg);
//     });
//   return programmaticSpeechChain;
// }

// /**
//  * @param {import("@livekit/agents").voice.AgentSession | null | undefined} session
//  * @param {string[]} digits
//  * @param {number} [gapMs]
//  */
// async function speakDigitsWithDelay(session, digits, gapMs = 1000, agent) {
//   if (!digits.length) return;
//   for (let i = 0; i < digits.length; i += 1) {
//     const word = digitToWord(digits[i]);
//     await speakInstructions(
//       session,
//       `Say ONLY this single English digit word, nothing else — no greeting, no extra words: "${word}"`,
//       agent,
//     );
//     if (i < digits.length - 1) {
//       await sleep(gapMs);
//     }
//   }
// }

// /**
//  * @param {{
//  *   session: import("@livekit/agents").voice.AgentSession | null | undefined,
//  *   lang: 'hi'|'gu',
//  *   hospitalName: string,
//  *   emergencyNumber: string,
//  *   gapMs?: number,
//  * }} p
//  */
// async function runEmergencyDigitAnnouncement(p) {
//   const { session, lang, hospitalName, emergencyNumber, gapMs = 1000, agent } = p;
//   const digits = extractEmergencyDigits(emergencyNumber);
//   if (agent && agent.callFlow) agent.callFlow.emergencyScriptActive = true;
//   try {
//     if (!digits.length) {
//       await speakInstructions(
//         session,
//         `In ${langLabel(lang)}: apologize briefly — emergency number is not configured — and ask them to visit the hospital reception immediately. Do NOT offer appointment booking.`,
//         agent,
//       );
//       return false;
//     }
//     await speakInstructions(
//       session,
//       `In ${langLabel(lang)}, say exactly this line and nothing else: "${getEmergencyIntro(lang, hospitalName)}"`,
//       agent,
//     );
//     await speakDigitsWithDelay(session, digits, gapMs, agent);
//     return true;
//   } finally {
//     if (agent && agent.callFlow) agent.callFlow.emergencyScriptActive = false;
//   }
// }

// /**
//  * @param {import("./agent").HospitalVoiceAgent} agent
//  * @param {import("@livekit/agents").voice.AgentSession | null | undefined} session
//  * @param {(event: string, extra?: object) => void} log
//  */
// async function endEmergencyCall(agent, session, log) {
//   agent.callFlow.phase = "emergency_ending";
//   agent.callFlow.emergencyStep = "done";
//   agent._emergencyHangupScheduled = true;
//   log("call_flow", { step: "emergency_disconnect_scheduled" });
//   console.log(
//     "[EndCall] endEmergencyCall invoked — scheduling room delete after thank-you idle",
//   );

//   const roomName =
//     (agent._callRoomName && String(agent._callRoomName)) ||
//     (agent.roomName && String(agent.roomName)) ||
//     "";
//   const logger =
//     typeof agent.getCallLogger === "function" ? agent.getCallLogger() : null;

//   const { endEmergencyPhoneCall } = require("./endCall");
//   const result = await endEmergencyPhoneCall({
//     roomName,
//     session,
//     logger,
//     reason: "emergency_flow_complete",
//   });
//   log("call_disconnect", result);
// }

// /**
//  * @param {{
//  *   agent: import("./agent").HospitalVoiceAgent,
//  *   rawUser: string,
//  *   normalizedUser: string,
//  * }} p
//  * @returns {Promise<boolean>} true if this turn was fully handled (caller should StopResponse)
//  */
// async function handleCallFlowTurn(p) {
//   const { agent, rawUser, normalizedUser } = p;
//   if (!agent || !agent.callFlow) return false;
//   if (agent.callFlow.phase === "emergency_ending") return true;

//   const lang = agent.preferredLanguage === "gu" ? "gu" : "hi";
//   const session = agent.session;
//   const logger =
//     typeof agent.getCallLogger === "function" ? agent.getCallLogger() : null;

//   const log = (event, extra = {}) => {
//     if (logger)
//       logger.log(event, { ...extra, callFlowPhase: agent.callFlow.phase });
//   };

//   if (
//     agent.callFlow.phase === "awaiting_language" &&
//     agent.preferredLanguageLocked
//   ) {
//     agent.callFlow.phase = "awaiting_case_type";
//     log("call_flow", { step: "ask_case_type", lang });
//     await speakInstructions(
//       session,
//       `You are Neha (female receptionist). The caller chose ${langLabel(lang)}. ` +
//         `Say exactly ONE short question in ${langLabel(lang)} and nothing else — do NOT ask about symptoms, doctors, or appointments yet: ` +
//         `"${buildCaseTypeQuestion(lang)}"`,
//       agent,
//     );
//     return true;
//   }

//   if (agent.callFlow.phase === "awaiting_case_type") {
//     const caseType = detectCaseType(rawUser || normalizedUser);
//     if (!caseType) {
//       await speakInstructions(
//         session,
//         `In ${langLabel(lang)}, politely ask again — emergency case or normal case? One short line only: "${buildCaseTypeQuestion(lang)}"`,
//         agent,
//       );
//       return true;
//     }

//     if (caseType === "normal") {
//       agent.callFlow.phase = "booking";
//       log("call_flow", { step: "normal_booking", lang });
//       return false;
//     }

//     agent.callFlow.phase = "emergency";
//     agent.callFlow.emergencyStep = "awaiting_repeat_or_note";
//     agent.callFlow.emergencyLlmActive = true;
//     log("call_flow", { step: "emergency_start", lang });
//     console.log("[CallFlow] emergency path — locking Realtime auto-replies");

//     lockEmergencyRealtimeReplies(agent, session);

//     const hasDigits = await runEmergencyDigitAnnouncement({
//       session,
//       lang,
//       hospitalName: agent.hospitalName,
//       emergencyNumber: agent.emergencyNumber,
//       agent,
//     });
//     if (hasDigits) {
//       await sleep(400);
//       await speakInstructions(
//         session,
//         `In ${langLabel(lang)}, say exactly: "${getAskRepeatOrNotedLine(lang)}"`,
//         agent,
//       );
//     }
//     return true;
//   }

//   if (
//     agent.callFlow.phase === "emergency" &&
//     agent.callFlow.emergencyStep === "awaiting_repeat_or_note"
//   ) {
//     const answer = detectRepeatOrNoted(rawUser, normalizedUser);

//     if (answer === "noted") {
//       const thankYou = getEmergencyThankYou(lang, agent.hospitalName);
//       await speakInstructions(
//         session,
//         `In ${langLabel(lang)}, say exactly this thank-you line and nothing else: "${thankYou}"`,
//         agent,
//       );
//       log("call_flow", { step: "emergency_thank_you", lang });
//       await endEmergencyCall(agent, session, log);
//       return true;
//     }

//     const digits = extractEmergencyDigits(agent.emergencyNumber);
//     if (answer === "repeat" || answer === null) {
//       if (digits.length) {
//         await speakDigitsWithDelay(session, digits, 1000, agent);
//         await sleep(400);
//       }
//       await speakInstructions(
//         session,
//         `In ${langLabel(lang)}, say exactly: "${getAskRepeatOrNotedLine(lang)}"`,
//         agent,
//       );
//       return true;
//     }

//     return true;
//   }

//   if (agent.callFlow.phase === "emergency") return true;

//   return false;
// }

// module.exports = {
//   sleep,
//   extractEmergencyDigits,
//   digitToWord,
//   buildCaseTypeQuestion,
//   getAskRepeatOrNotedLine,
//   detectCaseType,
//   detectRepeatOrNoted,
//   getEmergencyIntro,
//   getEmergencyThankYou,
//   speakDigitsWithDelay,
//   runEmergencyDigitAnnouncement,
//   endEmergencyCall,
//   handleCallFlowTurn,
//   lockEmergencyRealtimeReplies,
//   isEmergencySpeechPhase,
//   pauseEmergencyRealtimeReplies,
// };

/**
 * Emergency vs normal case flow for the hospital voice agent.
 * After language lock (Hindi / Gujarati only), caller is asked case type;
 * emergency path reads DB number digit-by-digit in English, then repeat/note loop.
 *
 * FIX #2: Strengthened emergency mode locking to prevent switching to booking flow
 */

/** @typedef {'awaiting_language'|'awaiting_case_type'|'emergency'|'emergency_ending'|'booking'} CallFlowPhase */

const DIGIT_WORDS_EN = [
  "zero",
  "one",
  "two",
  "three",
  "four",
  "five",
  "six",
  "seven",
  "eight",
  "nine",
];

const EMERGENCY_RE =
  /\b(emergency|emerjency|imergency|urgent|critical|ambulance|aapatkal|aapat|आपात|इमरजेंसी|इमर्जेंसी|एमर्जेंसी|एमर्जन्सी|इमर्जन्सी|एम्बुलेंस|एम्बुलेन्स|क्रिटिकल|तत्काल)\b|ઇમરજન્સી|ઈમરજન્સી|આપત્તિ|आपातकाल|emergency\s*case|इमरजेंसी\s*केस|ambulance\s*needed|critical\s*case|critical\s*condition/i;

const NORMAL_RE =
  /\b(normal|routine|regular|appointment|booking|opd)\b|सामान्य|नॉर्मल|रूटीन|अपॉइंटमेंट|बुकिंग|સામાન્ય|નોર્મલ|રૂટીન|એપોઇન્ટમેન્ટ|normal\s*case|सामान्य\s*केस/i;

const NOTED_RE =
  /note|not\s*kar|नोट|नोंध|likh|लिख|le liya|ले लिया|kar liya|kar liya hai|कर लिया|likh liya|लिख लिया|note kiya|not kiya|ho gaya|mil gaya|samajh|જ લીધ|નોંધ|લખ/i;

const REPEAT_RE =
  /repeat|dubara|dohbara|dobara|phir se|फिर से|दोबारा|farithi|ફરી|bol do|boliye|bolo|बोल|repeat kar|farithi bol/i;

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * @param {string} raw
 * @returns {string[]}
 */
function extractEmergencyDigits(raw) {
  const digits = String(raw || "").replace(/\D/g, "");
  if (!digits) return [];
  return digits.split("");
}

/** Emergency digits are always spoken in English (nine, eight, seven…). */
function digitToWord(digitChar) {
  const n = Number(digitChar);
  if (Number.isFinite(n) && n >= 0 && n <= 9) return DIGIT_WORDS_EN[n];
  return digitChar;
}

/** @param {'hi'|'gu'} lang */
function langLabel(lang) {
  return lang === "gu" ? "Gujarati" : "Hindi";
}

/** @param {'hi'|'gu'} lang */
function buildCaseTypeQuestion(lang) {
  if (lang === "gu") {
    return "કૃપા કરીને જણાવો — આ કઈ રીતનો કેસ છે: ઇમરજન્સી કે સામાન્ય?";
  }
  return "कृपया बताइए — यह इमरजेंसी केस है या सामान्य केस?";
}

/** @param {'hi'|'gu'} lang */
function getAskRepeatOrNotedLine(lang) {
  if (lang === "gu") {
    return "શું હું નંબર ફરી બોલું, કે તમે નોંધી લીધું છે?";
  }
  return "क्या मैं नंबर दोबारा बोलूँ, या आपने नोट कर लिया है?";
}

/**
 * @param {'hi'|'gu'} lang
 * @param {string} hospitalName
 */
function getEmergencyIntro(lang, hospitalName) {
  const name = hospitalName || "अस्पताल";
  if (lang === "gu") {
    return `કૃપા કરીને ધ્યાનથી સાંભળો. ${name} નો ઇમરજન્સી નંબર છે:`;
  }
  return `कृपया ध्यान से सुनिए। ${name} का इमरजेंसी नंबर है:`;
}

/**
 * @param {'hi'|'gu'} lang
 * @param {string} hospitalName
 */
function getEmergencyThankYou(lang, hospitalName) {
  const name = hospitalName || "अस्पताल";
  if (lang === "gu") {
    return `${name} માં ફોન કરવા બદલ આભાર.`;
  }
  return `${name} में फ़ोन करने के लिए धन्यवाद।`;
}

/**
 * @param {string} text
 * @returns {'emergency'|'normal'|null}
 */
function detectCaseType(text) {
  const s = String(text || "").trim();
  if (!s || s.length > 200) return null;
  if (EMERGENCY_RE.test(s)) return "emergency";
  if (NORMAL_RE.test(s)) return "normal";
  return null;
}

/** Utterance is only emergency/normal case selection — not booking content. */
function isCaseTypeOnlyText(text) {
  const t = String(text || "").trim();
  if (!t || t.length > 80) return false;
  if (!detectCaseType(t)) return false;
  if (/दर्द|dard|pain|fever|doctor|डॉक|bimari|symptom|appointment|तारीख|time|slot/i.test(t)) {
    return false;
  }
  return true;
}

/**
 * @param {string} rawUser
 * @param {string} normalizedUser
 * @returns {'noted'|'repeat'|null}
 */
function detectRepeatOrNoted(rawUser, normalizedUser) {
  const s = String(rawUser || "").trim();
  if (!s) return null;
  if (NOTED_RE.test(s)) return "noted";
  if (REPEAT_RE.test(s)) return "repeat";

  const {
    isAffirmativeTurn,
    isNegationTurn,
  } = require("./userTranscriptNormalize");
  if (isNegationTurn(rawUser, normalizedUser)) return "repeat";
  if (isAffirmativeTurn(rawUser, normalizedUser)) return "noted";
  return null;
}

/**
 * FIX #2: Pause Realtime auto-replies during emergency
 * @param {import("@livekit/agents").voice.AgentSession | null | undefined} session
 */
function pauseEmergencyRealtimeReplies(session) {
  if (!session || typeof session.pauseReplyAuthorization !== "function") return;
  try {
    session.pauseReplyAuthorization();
    console.log("[EmergencyFlow] Realtime auto-replies PAUSED");
  } catch (_) {
    /* ignore */
  }
}

/**
 * FIX #2: Resume Realtime auto-replies for programmatic speech
 * @param {import("@livekit/agents").voice.AgentSession | null | undefined} session
 */
function resumeEmergencyRealtimeForSpeech(session) {
  if (!session || typeof session.resumeReplyAuthorization !== "function")
    return;
  try {
    session.resumeReplyAuthorization();
    console.log(
      "[EmergencyFlow] Realtime auto-replies RESUMED for programmatic speech",
    );
  } catch (_) {
    /* ignore */
  }
}

/** @param {import("./agent").HospitalVoiceAgent | null | undefined} agent */
function isEmergencySpeechPhase(agent) {
  const cf = agent && agent.callFlow;
  if (!cf) return false;
  return (
    cf.phase === "emergency" ||
    cf.phase === "emergency_ending" ||
    Boolean(cf.emergencyLlmActive) ||
    Boolean(cf.emergencyScriptActive)
  );
}

/**
 * FIX #2: Strengthen emergency mode lock
 * This prevents Realtime from continuing to generate booking-related responses
 * @param {import("./agent").HospitalVoiceAgent} agent
 * @param {import("@livekit/agents").voice.AgentSession | null | undefined} session
 */
function lockEmergencyRealtimeReplies(agent, session) {
  if (!agent || !agent.callFlow) return;

  // FIX #2: Set BOTH flags to ensure hard lock
  agent.callFlow.emergencyLlmActive = true;
  agent.callFlow.emergencyScriptActive = true; // Keep script flag during emergency

  pauseEmergencyRealtimeReplies(session);

  console.log(
    "[EmergencyFlow] ✓ LOCKED emergency mode: emergencyLlmActive=true, emergencyScriptActive=true",
    "| Phase:",
    agent.callFlow.phase,
  );
}

/** @param {import("./agent").HospitalVoiceAgent | null | undefined} agent */
function shouldKeepRealtimeReplyPaused(agent) {
  const cf = agent && agent.callFlow;
  if (!cf) return false;

  // FIX #2: Keep paused during entire emergency flow including transition states
  return (
    cf.phase === "awaiting_language" ||
    cf.phase === "awaiting_case_type" ||
    cf.phase === "emergency" ||
    cf.phase === "emergency_ending" ||
    Boolean(cf.emergencyLlmActive) ||
    Boolean(cf.emergencyScriptActive)
  );
}

/** Serialize programmatic Realtime speech so responses do not collide. */
let programmaticSpeechChain = Promise.resolve();

/**
 * FIX #2: Enhanced speech instructions with emergency guard
 * @param {import("@livekit/agents").voice.AgentSession | null | undefined} session
 * @param {string} instructions
 * @param {import("./agent").HospitalVoiceAgent | null | undefined} [agent]
 */
async function speakInstructionsOnce(session, instructions, agent) {
  if (!session || typeof session.generateReply !== "function") return;
  if (session.closing) return;

  resumeEmergencyRealtimeForSpeech(session);

  if (typeof session.interrupt === "function") {
    try {
      await session.interrupt({ force: true });
    } catch (_) {
      /* ignore */
    }
  }

  try {
    const { waitForStableAgentIdle } = require("./endCall");
    await waitForStableAgentIdle(session, 500);
  } catch (_) {
    /* ignore */
  }

  if (session.closing) return;

  // Second interrupt — kills any Realtime auto-reply that started during the idle wait
  if (typeof session.interrupt === "function") {
    try {
      await session.interrupt({ force: true });
    } catch (_) {
      /* ignore */
    }
  }

  const emergency = isEmergencySpeechPhase(agent);

  const emergencyGuard = emergency
    ? " *** CRITICAL EMERGENCY MODE ONLY ***\n" +
      "Do NOT greet the caller. Do NOT say 'how can I help you' or 'main aapki kaise madad kar sakta hoon' or any similar phrase.\n" +
      "Do NOT ask ANY questions whatsoever.\n" +
      "Do NOT ask about symptoms, disease, doctors, appointments, or booking.\n" +
      "Do NOT mention normal case or appointment flow.\n" +
      "Say ONLY the exact requested line and stop immediately.\n" +
      "After speaking, await the next instruction.\n" +
      "Do NOT continue auto-generating speech."
    : "";

  let handle;
  try {
    handle = session.generateReply({
      toolChoice: "none",
      instructions: `${instructions}${emergencyGuard}`,
    });
  } catch (err) {
    const msg = err && err.message ? err.message : String(err);
    console.error("[CallFlow] speakInstructions generateReply failed:", msg);
    if (shouldKeepRealtimeReplyPaused(agent)) {
      pauseEmergencyRealtimeReplies(session);
    }
    return;
  }

  // Wait for full playout BEFORE pausing — pausing early cancels the queued reply
  if (handle && typeof handle.waitForPlayout === "function") {
    try {
      await handle.waitForPlayout();
    } catch (err) {
      const msg = err && err.message ? err.message : String(err);
      console.warn("[CallFlow] speakInstructions waitForPlayout:", msg);
    }
  }

  if (shouldKeepRealtimeReplyPaused(agent)) {
    pauseEmergencyRealtimeReplies(session);
  }
}

async function speakInstructions(session, instructions, agent) {
  programmaticSpeechChain = programmaticSpeechChain
    .then(() => speakInstructionsOnce(session, instructions, agent))
    .catch((err) => {
      const msg = err && err.message ? err.message : String(err);
      console.error("[CallFlow] speakInstructions chain error:", msg);
      // Reset chain on error so future calls are not blocked
      programmaticSpeechChain = Promise.resolve();
    });
  return programmaticSpeechChain;
}

/**
 * @param {import("@livekit/agents").voice.AgentSession | null | undefined} session
 * @param {string[]} digits
 * @param {number} [gapMs]
 * @param {import("./agent").HospitalVoiceAgent} [agent]
 */
async function speakDigitsWithDelay(session, digits, gapMs = 1000, agent) {
  if (!digits.length) return;
  for (let i = 0; i < digits.length; i += 1) {
    const word = digitToWord(digits[i]);
    await speakInstructions(
      session,
      `Say ONLY this single digit word: "${word}". ` +
        `Nothing before it, nothing after it. No greeting, no sentence, no language switch. ` +
        `Speak just the word "${word}" and then immediately stop.`,
      agent,
    );
    if (i < digits.length - 1) {
      await sleep(gapMs);
    }
  }
}

/**
 * FIX #2: Enhanced emergency digit announcement with state locking
 * @param {{
 *   session: import("@livekit/agents").voice.AgentSession | null | undefined,
 *   lang: 'hi'|'gu',
 *   hospitalName: string,
 *   emergencyNumber: string,
 *   gapMs?: number,
 *   agent?: import("./agent").HospitalVoiceAgent,
 * }} p
 */
async function runEmergencyDigitAnnouncement(p) {
  const {
    session,
    lang,
    hospitalName,
    emergencyNumber,
    gapMs = 1000,
    agent,
  } = p;
  const digits = extractEmergencyDigits(emergencyNumber);

  if (agent && agent.callFlow) {
    agent.callFlow.emergencyScriptActive = true;
    console.log(
      "[EmergencyFlow] ↳ emergencyScriptActive=true (starting digit announcement)",
    );
  }

  // No finally reset here — emergencyScriptActive stays true until endEmergencyCall clears it.
  // Resetting it early was causing Realtime to resume auto-replies mid-announcement.
  if (!digits.length) {
    await speakInstructions(
      session,
      `In ${langLabel(lang)}: apologize briefly — emergency number is not configured — and ask them to visit the hospital reception immediately. Do NOT offer appointment booking.`,
      agent,
    );
    return false;
  }

  await speakInstructions(
    session,
    `In ${langLabel(lang)}, say exactly this line and nothing else: "${getEmergencyIntro(lang, hospitalName)}"`,
    agent,
  );

  await speakDigitsWithDelay(session, digits, gapMs, agent);
  return true;
}

/**
 * Speaks "Emergency number is 102. Thank you for calling [Hospital]." in one shot.
 * Static 102 — no DB fetch, no digit loop, no repeat/noted interaction.
 */
async function runSimpleEmergencyFlow({ session, lang, hospitalName, agent }) {
  const name = String(hospitalName || "").trim();
  let msg;
  if (lang === "gu") {
    msg =
      `આ ઇમરજન્સી છે. કૃપા કરીને ઇમરજન્સી નંબર 102 પર ફોન કરો. ` +
      `${name || "હોસ્પિટલ"} માં ફોન કરવા બદલ આભાર.`;
  } else {
    msg =
      `यह इमरजेंसी है। कृपया इमरजेंसी नंबर 102 पर कॉल करें। ` +
      `${name || "अस्पताल"} में फ़ोन करने के लिए धन्यवाद।`;
  }
  console.log("[EmergencyFlow] simple emergency message →", msg);
  await speakInstructions(
    session,
    `Say EXACTLY this message word for word, do not add or remove anything. Do NOT greet. Do NOT ask any questions. Do NOT say 'how can I help you'. Just speak this line only: "${msg}"`,
    agent,
  );
}

/**
 * @param {import("./agent").HospitalVoiceAgent} agent
 * @param {import("@livekit/agents").voice.AgentSession | null | undefined} session
 * @param {(event: string, extra?: object) => void} log
 */
async function endEmergencyCall(agent, session, log) {
  agent.callFlow.phase = "emergency_ending";
  agent.callFlow.emergencyStep = "done";
  agent.callFlow.emergencyScriptActive = false;
  agent._emergencyHangupScheduled = true;
  log("call_flow", { step: "emergency_disconnect_scheduled" });
  console.log(
    "[EndCall] endEmergencyCall invoked — scheduling room delete after thank-you idle",
  );

  const roomName =
    (agent._callRoomName && String(agent._callRoomName)) ||
    (agent.roomName && String(agent.roomName)) ||
    "";
  const logger =
    typeof agent.getCallLogger === "function" ? agent.getCallLogger() : null;

  const { endEmergencyPhoneCall } = require("./endCall");
  const result = await endEmergencyPhoneCall({
    roomName,
    session,
    logger,
    reason: "emergency_flow_complete",
  });
  log("call_disconnect", result);
}

/**
 * FIX #2: Enhanced call flow handling with better emergency state management
 * @param {{
 *   agent: import("./agent").HospitalVoiceAgent,
 *   rawUser: string,
 *   normalizedUser: string,
 * }} p
 * @returns {Promise<boolean>} true if this turn was fully handled (caller should StopResponse)
 */
async function handleCallFlowTurn(p) {
  const { agent, rawUser, normalizedUser } = p;
  if (!agent || !agent.callFlow) return false;
  if (agent.callFlow.phase === "emergency_ending") return true;

  const lang = agent.preferredLanguage === "gu" ? "gu" : "hi";
  const session = agent.session;
  const logger =
    typeof agent.getCallLogger === "function" ? agent.getCallLogger() : null;

  const log = (event, extra = {}) => {
    if (logger)
      logger.log(event, { ...extra, callFlowPhase: agent.callFlow.phase });
  };

  // Language selection phase — also catches emergency stated in first utterance
  if (agent.callFlow.phase === "awaiting_language") {
    const earlyEmergency = detectCaseType(rawUser || normalizedUser);
    if (earlyEmergency === "emergency") {
      if (!agent.preferredLanguageLocked) {
        agent.preferredLanguage = "hi";
        agent.preferredLanguageLocked = true;
      }
      agent.callFlow.phase = "emergency";
      agent.callFlow.emergencyLlmActive = true;
      agent.callFlow.emergencyScriptActive = true;
      log("call_flow", { step: "emergency_start", lang });
      console.log("[CallFlow] Emergency in language phase → simple emergency flow");
      lockEmergencyRealtimeReplies(agent, session);
      await runSimpleEmergencyFlow({ session, lang, hospitalName: agent.hospitalName, agent });
      if (!agent._emergencyHangupScheduled) {
        await endEmergencyCall(agent, session, log);
      }
      return true;
    }

    if (!agent.preferredLanguageLocked) return false;

    agent.callFlow.phase = "awaiting_case_type";
    log("call_flow", { step: "ask_case_type", lang });
    await speakInstructions(
      session,
      `You are Neha (female receptionist). The caller chose ${langLabel(lang)}. ` +
        `Say exactly ONE short question in ${langLabel(lang)} and nothing else — do NOT ask about symptoms, doctors, or appointments yet: ` +
        `"${buildCaseTypeQuestion(lang)}"`,
      agent,
    );
    return true;
  }

  // Case type selection phase (emergency vs normal)
  if (agent.callFlow.phase === "awaiting_case_type") {
    const caseType = detectCaseType(rawUser || normalizedUser);
    if (!caseType) {
      await speakInstructions(
        session,
        `In ${langLabel(lang)}, politely ask again — emergency case or normal case? One short line only: "${buildCaseTypeQuestion(lang)}"`,
        agent,
      );
      return true;
    }

    if (caseType === "normal") {
      agent.callFlow.phase = "booking";
      log("call_flow", { step: "normal_booking", lang });
      console.log("[CallFlow] ✓ Transitioning to BOOKING flow — asking visit reason");
      const { getBookingKickoffInstructions } = require("./bookingTurnInstructions");
      await speakInstructions(
        session,
        getBookingKickoffInstructions(lang),
        agent,
      );
      return true;
    }

    // Emergency path — speak 102 + thank you + disconnect
    agent.callFlow.phase = "emergency";
    agent.callFlow.emergencyLlmActive = true;
    agent.callFlow.emergencyScriptActive = true;
    log("call_flow", { step: "emergency_start", lang });
    console.log("[CallFlow] Emergency detected → simple emergency flow");
    lockEmergencyRealtimeReplies(agent, session);
    await runSimpleEmergencyFlow({ session, lang, hospitalName: agent.hospitalName, agent });
    if (!agent._emergencyHangupScheduled) {
      await endEmergencyCall(agent, session, log);
    }
    return true;
  }

  // Any emergency phase — consume turn, do not leak to booking
  if (agent.callFlow.phase === "emergency") {
    if (!agent._emergencyHangupScheduled) {
      await endEmergencyCall(agent, session, log);
    }
    return true;
  }

  return false;
}

module.exports = {
  sleep,
  extractEmergencyDigits,
  digitToWord,
  buildCaseTypeQuestion,
  getAskRepeatOrNotedLine,
  detectCaseType,
  isCaseTypeOnlyText,
  detectRepeatOrNoted,
  getEmergencyIntro,
  getEmergencyThankYou,
  speakDigitsWithDelay,
  runEmergencyDigitAnnouncement,
  runSimpleEmergencyFlow,
  endEmergencyCall,
  handleCallFlowTurn,
  lockEmergencyRealtimeReplies,
  isEmergencySpeechPhase,
  pauseEmergencyRealtimeReplies,
  resumeEmergencyRealtimeForSpeech,
  shouldKeepRealtimeReplyPaused,
};
