const { voice, llm } = require("@livekit/agents");
const { getRealtimeTools } = require("../src/agent/realtimeTools");
const { runHospitalTool } = require("../src/agent/realtimeToolHandlers");
const {
  normalizeShortYesNoInPlace,
  getPlainTranscript,
} = require("./userTranscriptNormalize");
const { buildBookingTurnInstructions, buildBookingDispatchInstructions, getBookingFlowStep, isBookingReadyForCreateAppointment, isBookingReadyForCreatePatient, getMissingBookingFields } = require("./bookingTurnInstructions");
const { applyTranscriptToBookingSlots } = require("./bookingSlotCapture");
const {
  getBookingThankYouLine,
  inferHospitalCallerLanguage,
  detectExplicitHospitalLanguageSwitch,
  getEmptyInputRepromptInstructions,
} = require("./preferredLanguage");
const { handleCallFlowTurn } = require("./emergencyFlow");
const {
  createCallBookingSlots,
  updateSlotsFromToolArgs,
  mergeToolArgsWithSlots,
  maybeCaptureVisitReasonFromTranscript,
  isMongoObjectIdString,
} = require("./callBookingSlots");

const SLOT_MERGE_TOOLS = new Set(["create_patient", "create_appointment"]);

/** @param {string} text */
function buildUserChatMessage(text) {
  const t = String(text || "").trim();
  if (llm && llm.ChatMessage && typeof llm.ChatMessage.create === "function") {
    return llm.ChatMessage.create({ role: "user", content: t });
  }
  return { role: "user", content: t };
}

/** Per-tool args allow-list for logs — keeps file readable without dumping sensitive blobs. */
function redactToolArgsForLog(name, args) {
  if (!args || typeof args !== "object") return {};
  const a = { ...args };
  if (a.phoneNumber)
    a.phoneNumber = String(a.phoneNumber).replace(/\d(?=\d{4})/g, "*");
  return a;
}

/**
 * @param {HospitalVoiceAgent} agent
 * @param {{ ok?: boolean, message?: string, messageHindi?: string, messageGujarati?: string, messageEnglish?: string, appointmentUpdated?: boolean }} result
 */
async function speakCreateAppointmentResult(agent, result) {
  if (!agent || !result || !agent.session) return;

  const lang =
    agent.preferredLanguage === "gu"
      ? "gu"
      : agent.preferredLanguage === "en"
        ? "en"
        : "hi";

  let primary;
  if (lang === "en") {
    primary =
      result.messageEnglish ||
      result.message ||
      result.messageHindi ||
      result.messageGujarati;
  } else if (lang === "gu") {
    primary = result.messageGujarati || result.messageHindi;
  } else {
    primary = result.messageHindi || result.messageGujarati || result.message;
  }

  if (!primary) return;

  if (typeof agent.session.resumeReplyAuthorization === "function") {
    try {
      agent.session.resumeReplyAuthorization();
    } catch (_) {
      /* ignore */
    }
  }
  agent.postBookingClosingInFlight = true;

  const thankYou = getBookingThankYouLine(lang, agent.hospitalName);
  const langLabel =
    lang === "gu" ? "Gujarati" : lang === "en" ? "English" : "Hindi";

  const BOOKING_END_GUARD =
    "\nCRITICAL: After speaking these lines, go completely silent. NEVER say 'aap call kat sakte hain', 'आप कॉल काट सकते हैं', 'phone muk sakte ho', 'you may hang up', 'goodbye', or any farewell phrase. The system disconnects automatically.";

  const instructions = result.ok
    ? result.appointmentUpdated
      ? "The appointment was updated (ok: true). Speak EXACTLY the status line below in " +
        langLabel +
        ", then the thank-you closing line. Do NOT say the update failed. Do NOT read internal English instructions. Do NOT change wording. Do NOT ask if they want to hang up — only the thank-you line.\n" +
        `Status: ${primary}\n` +
        `Thank-you closing: ${thankYou}` +
        BOOKING_END_GUARD
      : "The appointment is booked (ok: true). Speak EXACTLY the booking status line below in " +
        langLabel +
        ", then the thank-you closing line. Do NOT say booking failed. Do NOT read internal English instructions. Do NOT change wording. Do NOT ask if they want to hang up — only the thank-you line.\n" +
        `Booking status: ${primary}\n` +
        `Thank-you closing: ${thankYou}\n` +
        "That status line is the ONLY full booking recap for this call." +
        BOOKING_END_GUARD
    : "Booking failed (ok: false). Speak EXACTLY the line below in " +
      langLabel +
      ". Explain calmly what they can do next. Do not read raw technical English.\n" +
      `Failure line: ${primary}`;

  const logger =
    agent && typeof agent.getCallLogger === "function"
      ? agent.getCallLogger()
      : null;
  if (logger) {
    logger.log("generate_reply", {
      purpose: result.ok
        ? result.appointmentUpdated
          ? "post_update_status"
          : "post_booking_status"
        : "post_booking_failure",
      lang,
    });
  }
  try {
    const handle = agent.session.generateReply({
      toolChoice: "none",
      instructions,
    });
    if (handle && typeof handle.waitForPlayout === "function") {
      await handle.waitForPlayout();
    }
    if (result.ok && agent.session && typeof agent.session.pauseReplyAuthorization === "function") {
      try {
        agent.session.pauseReplyAuthorization();
      } catch (_) { /* ignore */ }
    }
  } catch (err) {
    const msg = err && err.message ? err.message : String(err);
    console.error("[Agent] post-booking generateReply error:", msg);
    if (logger) {
      logger.log("generate_reply_error", {
        purpose: "post_booking_status",
        errorMessage: msg,
      });
    }
  }
}

/**
 * Build LiveKit function tools from OpenAI-style definitions, backed by runHospitalTool.
 */
function buildHospitalTools(hospitalObjectId, callerPhone, agentRef) {
  const defs = getRealtimeTools();
  const tools = {};
  for (const def of defs) {
    const name = def.name;
    if (!name) continue;
    tools[name] = llm.tool({
      description: def.description || "",
      parameters: def.parameters,
      execute: async (args) => {
        const agent = agentRef && agentRef.current;
        if (
          agent &&
          agent.callFlow &&
          (agent.callFlow.phase === "emergency" ||
            agent.callFlow.phase === "emergency_ending" ||
            agent.callFlow.phase === "awaiting_case_type" ||
            agent.callFlow.phase === "awaiting_language")
        ) {
          return {
            ok: false,
            code: "CALL_FLOW_BLOCKED",
            message:
              "Appointment tools are not available during language selection or emergency flow.",
          };
        }
        if (agent && name === "create_patient") {
          if (!isBookingReadyForCreatePatient(agent.callBookingSlots)) {
            const missing = getMissingBookingFields(agent.callBookingSlots).filter(
              (f) => f !== "doctor" && f !== "dateTime",
            );
            return {
              ok: false,
              code: "PATIENT_INCOMPLETE",
              message: `Cannot register patient yet. Missing: ${missing.join(", ") || "patient details"}. Ask the caller first.`,
              messageHindi:
                "अभी patient register नहीं हो सकता — पहले नाम, उम्र, लिंग और visit reason पूछिए।",
            };
          }
        }
        if (agent && name === "create_appointment") {
          if (!isBookingReadyForCreateAppointment(agent.callBookingSlots)) {
            const missing = getMissingBookingFields(agent.callBookingSlots);
            return {
              ok: false,
              code: "BOOKING_INCOMPLETE",
              message: `Cannot book yet. Missing: ${missing.join(", ")}. Collect each field before booking.`,
              messageHindi:
                "अभी appointment book नहीं हो सकती — पहले visit reason, नाम, उम्र, लिंग, doctor और date-time लीजिए।",
            };
          }
          if (!agent.callBookingSlots.readBackOffered) {
            return {
              ok: false,
              code: "BOOKING_NOT_CONFIRMED",
              message:
                "Do one full read-back and get caller confirmation before create_appointment.",
              messageHindi:
                "पहले पूरी booking read-back करके caller से हाँ confirm करवाइए, फिर book करें।",
            };
          }
        }
        const logger =
          agent && typeof agent.getCallLogger === "function"
            ? agent.getCallLogger()
            : null;
        const rawArgs = args && typeof args === "object" ? args : {};
        const mergedArgs =
          agent && SLOT_MERGE_TOOLS.has(name)
            ? mergeToolArgsWithSlots(agent.callBookingSlots, rawArgs)
            : rawArgs;

        const toolStart = Date.now();
        if (logger) {
          logger.log("tool_start", {
            name,
            args: redactToolArgsForLog(name, mergedArgs),
          });
        }

        let result;
        try {
          result = await runHospitalTool(hospitalObjectId, name, mergedArgs, {
            callerPhone: callerPhone || null,
            callBookingSlots: agent ? agent.callBookingSlots : null,
          });
        } catch (toolErr) {
          const msg =
            toolErr && toolErr.message ? toolErr.message : String(toolErr);
          console.error(`[Agent] tool ${name} threw:`, msg);
          if (logger) {
            logger.log("tool_end", {
              name,
              ok: false,
              durationMs: Date.now() - toolStart,
              code: "TOOL_THREW",
              errorMessage: msg,
            });
          }
          /** Surface as a structured failure so the model recovers naturally. */
          return { ok: false, code: "TOOL_THREW", message: msg };
        }

        if (logger) {
          logger.log("tool_end", {
            name,
            ok: Boolean(result && result.ok),
            durationMs: Date.now() - toolStart,
            code: result && result.code ? String(result.code) : null,
            errorMessage:
              result && !result.ok && result.message
                ? String(result.message)
                : null,
            hasMessageHindi: Boolean(result && result.messageHindi),
            hasMessageGujarati: Boolean(result && result.messageGujarati),
            appointmentId:
              result && result.appointment
                ? result.appointment.appointmentId
                : null,
          });
        }

        if (agent) {
          if (
            name === "create_patient" &&
            result &&
            result.ok &&
            result.patient &&
            result.patient._id
          ) {
            agent.callBookingSlots.patientObjectId = String(result.patient._id);
          }
          if (
            (name === "list_doctors" || name === "search_doctors") &&
            agent &&
            agent.callBookingSlots &&
            agent.callBookingSlots.doctorOffered &&
            !isMongoObjectIdString(agent.callBookingSlots.doctorObjectId) &&
            result &&
            result.ok &&
            Array.isArray(result.doctors) &&
            result.doctors.length === 1 &&
            result.doctors[0]._id
          ) {
            agent.callBookingSlots.doctorObjectId = String(result.doctors[0]._id);
          }
          updateSlotsFromToolArgs(agent.callBookingSlots, mergedArgs);

          /**
           * If create_appointment failed because the chosen doctor reference was wrong,
           * DROP any stale slot doctor id — otherwise mergeToolArgsWithSlots silently
           * re-attaches Yugen on the NEXT call when the model omits doctorObjectId
           * (common after narration). Without this fix the agent can verbally pivot to
           * "Dr Asha Patel" yet still POST book with stale Dr Yugen's id from slots.
           */
          if (
            name === "create_appointment" &&
            result &&
            !result.ok &&
            result.code === "INVALID_DOCTOR_REF"
          ) {
            if (agent.callBookingSlots) {
              delete agent.callBookingSlots.doctorObjectId;
            }
          }

          if (
            name === "create_appointment" &&
            result &&
            result.ok &&
            result.appointment &&
            result.appointment.doctor &&
            isMongoObjectIdString(String(result.appointment.doctor))
          ) {
            /** Sync slot doctor reference to whoever was actually booked. */
            agent.callBookingSlots.doctorObjectId = String(
              result.appointment.doctor,
            );
          }
        }

        if (name === "create_appointment" && result) {
          if (
            agent &&
            result.ok &&
            result.appointment &&
            result.appointment._id
          ) {
            agent.callBookingSlots.appointmentObjectId = String(
              result.appointment._id,
            );
          }
          if (agent) {
            await speakCreateAppointmentResult(agent, result);
            if (result.ok) {
              const {
                scheduleAutoEndAfterBookingConfirmed,
              } = require("./endCall");
              scheduleAutoEndAfterBookingConfirmed({ agent });
            }
          }
        }

        return result;
      },
    });
  }
  return tools;
}

class HospitalVoiceAgent extends voice.Agent {
  constructor({
    instructions,
    hospitalObjectId,
    callerPhone,
    hospitalName = "",
    emergencyNumber = "",
    room = null,
    roomName = "",
    agentIdentity = "",
    shutdownJob = null,
    /** When true, user speech is transcribed by Sarvam and sent as text into OpenAI Realtime (see main.js). */
    routeUserTextThroughRealtime = false,
    /** Optional getter so this agent can pull the per-call logger lazily from main.js. */
    getCallLogger = null,
  }) {
    const agentRef = { current: null };
    super({
      instructions,
      tools: buildHospitalTools(hospitalObjectId, callerPhone, agentRef),
    });
    agentRef.current = this;
    this._routeUserTextThroughRealtime = routeUserTextThroughRealtime;
    this._getCallLogger =
      typeof getCallLogger === "function" ? getCallLogger : null;
    /** @type {'hi' | 'gu' | 'en'} */
    this.preferredLanguage = "hi";
    /** After first confident hi/gu/en detection (or explicit switch), STT heuristics must not flip language mid-call. */
    this.preferredLanguageLocked = false;
    this.hospitalName = String(hospitalName || "").trim();
    this.emergencyNumber = String(emergencyNumber || "").trim();
    this.room = room || null;
    this.roomName = String(roomName || "").trim();
    this._callRoomName = this.roomName;
    this.agentIdentity = String(agentIdentity || "").trim();
    this.shutdownJob = typeof shutdownJob === "function" ? shutdownJob : null;
    /** @type {{ phase: string, emergencyStep: string|null, emergencyLlmActive?: boolean }} */
    this.callFlow = {
      phase: "awaiting_language",
      emergencyStep: null,
      emergencyLlmActive: false,
      emergencyScriptActive: false,
    };
    this._emergencyHangupScheduled = false;
    this.callBookingSlots = createCallBookingSlots();
  }

  /** Returns the per-call logger if main.js wired one up; null otherwise. */
  getCallLogger() {
    if (!this._getCallLogger) return null;
    try {
      return this._getCallLogger();
    } catch (_) {
      return null;
    }
  }

  /**
   * Sync preferred language from user text (Sarvam STT). Locked after first inference so English
   * or mixed snippets do not override the chosen language; use detectExplicitHospitalLanguageSwitch when locked.
   * @param {string} text
   */
  updateLanguageFromTranscript(text) {
    const raw = String(text || "").trim();
    if (!raw) return;
    const wasLocked = this.preferredLanguageLocked;
    const next = wasLocked
      ? detectExplicitHospitalLanguageSwitch(raw)
      : inferHospitalCallerLanguage(raw);
    if (!next) return;
    const prev = this.preferredLanguage;
    this.preferredLanguage = next;
    if (!this.preferredLanguageLocked) this.preferredLanguageLocked = true;
    if (prev !== next) {
      const logger = this.getCallLogger();
      if (logger) {
        logger.log("language_detected", {
          lang: next,
          previous: prev,
          locked: this.preferredLanguageLocked,
          from: raw.slice(0, 80),
        });
      }
    }
  }

  /** Internal: small summary of captured slots (booleans only) for log lines. */
  _slotsSummaryForLog() {
    const s = this.callBookingSlots || {};
    return (
      [
        s.fullName ? "name" : null,
        s.age != null ? "age" : null,
        s.gender ? "gender" : null,
        s.reason ? "reason" : null,
        s.doctorObjectId ? "doctor" : null,
        s.appointmentDateTimeISO ? "datetime" : null,
        s.patientObjectId ? "patient" : null,
        s.appointmentObjectId ? "appointment" : null,
      ]
        .filter(Boolean)
        .join(",") || "(none)"
    );
  }

  /**
   * Sarvam STT + Realtime: callFlowBridge handles STT finals and programmatic speech.
   * @param {string} rawUser
   * @param {string} normalizedUser
   */
  async dispatchSarvamRealtimeUserTurn(rawUser, normalizedUser) {
    const rawBefore = String(rawUser || "").trim();
    const textAfter = String(normalizedUser || "").trim();
    const logger = this.getCallLogger();
    const session = this.session;
    if (!session || typeof session.generateReply !== "function") return;

    if (typeof session.resumeReplyAuthorization === "function") {
      try {
        session.resumeReplyAuthorization();
      } catch (_) {
        /* ignore */
      }
    }

    if (!rawBefore) {
      if (logger) {
        logger.log("reprompt", { reason: "empty_stt", lang: this.preferredLanguage });
      }
      try {
        session.generateReply({
          toolChoice: "none",
          instructions: getEmptyInputRepromptInstructions(this.preferredLanguage),
        });
      } catch (err) {
        console.warn("[Agent] empty STT reprompt error:", err && err.message ? err.message : err);
      }
      return;
    }

    if (this.callFlow.phase !== "booking") return;

    const step = getBookingFlowStep(
      this.callBookingSlots,
      rawBefore,
      textAfter,
    );

    let bookingIx;
    try {
      bookingIx = buildBookingDispatchInstructions({
        slots: this.callBookingSlots,
        rawUser: rawBefore,
        normalizedUser: textAfter,
        preferredLanguage: this.preferredLanguage,
      });
    } catch (err) {
      const msg = err && err.message ? err.message : String(err);
      console.error("[Agent] buildBookingDispatchInstructions failed:", msg);
      bookingIx =
        this.preferredLanguage === "en"
          ? "Reply in English only as Neha, the female receptionist."
          : this.preferredLanguage === "gu"
            ? "Reply in Gujarati only as Neha, the female receptionist."
            : "Reply in Hindi only as Neha, the female receptionist.";
    }

    const toolChoice =
      step === "book" || step === "doctor_lock" ? "auto" : "none";

    if (logger) {
      logger.log("generate_reply", {
        purpose: "user_turn",
        lang: this.preferredLanguage,
        bookingStep: step || "(unknown)",
        toolChoice,
        slotsSummary: this._slotsSummaryForLog(),
        userText: rawBefore.length > 200 ? `${rawBefore.slice(0, 200)}…` : rawBefore,
      });
    }

    const userMessage = buildUserChatMessage(rawBefore);
    try {
      normalizeShortYesNoInPlace(userMessage);
    } catch (_) {
      /* ignore */
    }

    try {
      const handle = session.generateReply({
        userMessage,
        instructions: bookingIx,
        toolChoice,
      });
      if (handle && typeof handle.waitForPlayout === "function") {
        await handle.waitForPlayout();
      }
      if (step === "doctor") {
        this.callBookingSlots.doctorOffered = true;
      }
      if (step === "confirm") {
        this.callBookingSlots.readBackOffered = true;
      }
    } catch (err) {
      const msg = err && err.message ? err.message : String(err);
      console.error("[Agent] generateReply (user_turn) failed:", msg);
      try {
        session.generateReply({
          toolChoice: "none",
          instructions: getEmptyInputRepromptInstructions(this.preferredLanguage),
        });
      } catch (_) {
        /* ignore */
      }
    }
  }

  /**
   * LiveKit clears STT output for RealtimeModel before generateReply; we inject Sarvam text here instead.
   */
  async onUserTurnCompleted(_chatCtx, newMessage) {
    if (this._routeUserTextThroughRealtime) {
      throw new voice.StopResponse();
    }

    const rawBefore = getPlainTranscript(newMessage);
    try {
      normalizeShortYesNoInPlace(newMessage);
    } catch (err) {
      console.warn(
        "[Agent] normalizeShortYesNoInPlace failed:",
        err && err.message ? err.message : err,
      );
    }
    const textAfter = getPlainTranscript(newMessage);
    const logger = this.getCallLogger();

    if (
      this._routeUserTextThroughRealtime &&
      process.env.SARVAM_STT_DEBUG !== "0"
    ) {
      const preview = rawBefore
        ? `"${rawBefore.slice(0, 200)}${rawBefore.length > 200 ? "…" : ""}"`
        : "(empty — reprompting caller)";
      console.log("[Sarvam STT] onUserTurnCompleted user text:", preview);
    }

    try {
      this.updateLanguageFromTranscript(rawBefore || textAfter);
    } catch (err) {
      console.warn(
        "[Agent] updateLanguageFromTranscript failed:",
        err && err.message ? err.message : err,
      );
    }

    if (
      this.callFlow.phase !== "emergency" &&
      this.callFlow.phase !== "emergency_ending"
    ) {
      try {
        applyTranscriptToBookingSlots(this.callBookingSlots, rawBefore);
      } catch (err) {
        console.warn(
          "[Agent] applyTranscriptToBookingSlots failed:",
          err && err.message ? err.message : err,
        );
      }
    }
    if (this.callFlow.phase === "booking") {
      try {
        maybeCaptureVisitReasonFromTranscript(this.callBookingSlots, rawBefore);
      } catch (err) {
        console.warn(
          "[Agent] maybeCaptureVisitReasonFromTranscript failed:",
          err && err.message ? err.message : err,
        );
      }
    }

    let callFlowHandled = false;
    try {
      callFlowHandled = await handleCallFlowTurn({
        agent: this,
        rawUser: rawBefore,
        normalizedUser: textAfter,
      });
    } catch (err) {
      console.error(
        "[Agent] handleCallFlowTurn failed:",
        err && err.message ? err.message : err,
      );
    }

    if (callFlowHandled) {
      if (logger) {
        logger.log("stop_response", { reason: "call_flow_handled" });
      }
      throw new voice.StopResponse();
    }

    if (
      this.callFlow.phase === "emergency" ||
      this.callFlow.phase === "emergency_ending"
    ) {
      if (logger) {
        logger.log("stop_response", { reason: "emergency_flow_active" });
      }
      throw new voice.StopResponse();
    }

    if (!this._routeUserTextThroughRealtime) return;

    if (!rawBefore.trim()) {
      if (logger) {
        logger.log("reprompt", {
          reason: "empty_stt",
          lang: this.preferredLanguage,
        });
      }
      try {
        this.session.generateReply({
          toolChoice: "none",
          instructions: getEmptyInputRepromptInstructions(
            this.preferredLanguage,
          ),
        });
      } catch (err) {
        const msg = err && err.message ? err.message : String(err);
        console.warn("[Agent] empty STT reprompt error:", msg);
        if (logger) {
          logger.log("generate_reply_error", {
            purpose: "empty_stt_reprompt",
            errorMessage: msg,
          });
        }
      }
      if (logger) {
        logger.log("stop_response", { reason: "empty_stt" });
      }
      throw new voice.StopResponse();
    }

    if (this.callFlow.phase !== "booking") {
      const { buildCaseTypeQuestion } = require("./emergencyFlow");
      const lang = this.preferredLanguage || "hi";
      let preBookingIx;
      if (this.callFlow.phase === "awaiting_case_type") {
        preBookingIx = `Ask exactly one short line in the caller's language: "${buildCaseTypeQuestion(lang)}" — do NOT start appointment booking.`;
      } else {
        preBookingIx =
          "The caller has not clearly chosen Hindi or Gujarati yet. Ask once more which language they prefer — Hindi or Gujarati only. Do NOT offer English. Do NOT start booking or ask about symptoms.";
      }
      try {
        this.session.generateReply({
          toolChoice: "none",
          instructions: preBookingIx,
        });
      } catch (err) {
        const msg = err && err.message ? err.message : String(err);
        console.warn("[Agent] pre-booking generateReply error:", msg);
      }
      if (logger) {
        logger.log("stop_response", { reason: "not_booking_phase" });
      }
      throw new voice.StopResponse();
    }

    let bookingIx;
    try {
      bookingIx = buildBookingTurnInstructions({
        slots: this.callBookingSlots,
        rawUser: rawBefore,
        normalizedUser: textAfter,
        preferredLanguage: this.preferredLanguage,
      });
    } catch (err) {
      const msg = err && err.message ? err.message : String(err);
      console.error("[Agent] buildBookingTurnInstructions failed:", msg);
      if (logger) {
        logger.log("generate_reply_error", {
          purpose: "build_booking_instructions",
          errorMessage: msg,
        });
      }
      bookingIx =
        this.preferredLanguage === "en"
          ? "Reply in English only as Neha, the female receptionist."
          : this.preferredLanguage === "gu"
            ? "Reply in Gujarati only as Neha, the female receptionist."
            : "Reply in Hindi only as Neha, the female receptionist.";
    }

    if (logger) {
      logger.log("generate_reply", {
        purpose: "user_turn",
        lang: this.preferredLanguage,
        slotsSummary: this._slotsSummaryForLog(),
        userText:
          rawBefore.length > 200 ? `${rawBefore.slice(0, 200)}…` : rawBefore,
      });
    }

    try {
      this.session.generateReply({
        userMessage: newMessage,
        instructions: bookingIx,
      });
    } catch (err) {
      const msg = err && err.message ? err.message : String(err);
      console.error("[Agent] generateReply (user_turn) failed:", msg);
      if (logger) {
        logger.log("generate_reply_error", {
          purpose: "user_turn",
          errorMessage: msg,
        });
      }
      /* Fallback: ask the caller to repeat in their language so the call does not go silent. */
      try {
        this.session.generateReply({
          toolChoice: "none",
          instructions: getEmptyInputRepromptInstructions(
            this.preferredLanguage,
          ),
        });
      } catch (fallbackErr) {
        console.warn(
          "[Agent] fallback reprompt also failed:",
          fallbackErr && fallbackErr.message
            ? fallbackErr.message
            : fallbackErr,
        );
      }
    }

    if (logger) {
      logger.log("stop_response", { reason: "user_turn_dispatched" });
    }
    throw new voice.StopResponse();
  }
}

module.exports = {
  HospitalVoiceAgent,
  buildHospitalTools,
  speakCreateAppointmentResult,
};
