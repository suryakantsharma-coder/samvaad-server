const { isAffirmativeTurn } = require("./userTranscriptNormalize");
const { isMongoObjectIdString } = require("./callBookingSlots");

/**
 * @param {import("./callBookingSlots").CallBookingSlots | null | undefined} slots
 * @returns {string[]}
 */
function getMissingBookingFields(slots) {
  const missing = [];
  if (!String(slots?.reason || "").trim()) missing.push("reason");
  if (!String(slots?.fullName || "").trim()) missing.push("fullName");
  if (slots?.age == null || !Number.isFinite(Number(slots.age))) missing.push("age");
  if (!String(slots?.gender || "").trim()) missing.push("gender");
  if (!isMongoObjectIdString(slots?.doctorObjectId)) missing.push("doctor");
  if (!String(slots?.appointmentDateTimeISO || "").trim()) missing.push("dateTime");
  return missing;
}

/** @param {import("./callBookingSlots").CallBookingSlots | null | undefined} slots */
function isBookingReadyForCreateAppointment(slots) {
  return getMissingBookingFields(slots).length === 0;
}

/** @param {import("./callBookingSlots").CallBookingSlots | null | undefined} slots */
function isBookingReadyForCreatePatient(slots) {
  const m = getMissingBookingFields(slots);
  return (
    !m.includes("reason") &&
    !m.includes("fullName") &&
    !m.includes("age") &&
    !m.includes("gender")
  );
}

/**
 * @param {import("./callBookingSlots").CallBookingSlots | null | undefined} slots
 * @returns {'reason'|'name'|'age_gender'|'doctor'|'datetime'|'confirm'|'book'|null}
 */
function getBookingFlowStep(slots, rawUser, normalizedUser) {
  const missing = getFirstMissingPatientField(slots);
  if (missing === "reason") return "reason";
  if (missing === "name") return "name";
  if (missing === "age_gender") return "age_gender";
  if (!isMongoObjectIdString(slots?.doctorObjectId)) {
    if (isAffirmativeTurn(rawUser, normalizedUser) && slots?.doctorOffered) {
      return "doctor_lock";
    }
    return "doctor";
  }
  if (!String(slots?.appointmentDateTimeISO || "").trim()) return "datetime";
  if (isBookingReadyForCreateAppointment(slots)) {
    if (isAffirmativeTurn(rawUser, normalizedUser) && slots?.readBackOffered) {
      return "book";
    }
    return "confirm";
  }
  return null;
}

function langLabel(lang) {
  return lang === "gu" ? "Gujarati" : lang === "en" ? "English" : "Hindi";
}

function getDoctorSuggestInstruction(lang) {
  const L = langLabel(lang);
  if (lang === "gu") {
    return (
      `In ${L}: From AVAILABLE DOCTORS in your instructions, pick ONE doctor whose specialty matches the visit reason. ` +
      `Tell the caller clearly: "આ સમસ્યા માટે Dr. [Name] ([specialty]) ઉપલબ્ધ છે." ` +
      `Then ask: "શું હું તેમની પાસે appointment બુક કરું?" ` +
      `Do NOT call create_appointment. Do NOT ask date/time yet. toolChoice=none this turn.`
    );
  }
  if (lang === "en") {
    return (
      `In ${L}: From AVAILABLE DOCTORS, pick ONE matching doctor. ` +
      `Say: "For this issue, Dr. [Name] ([specialty]) is available." ` +
      `Ask: "Shall I book an appointment with them?" ` +
      `Do NOT book yet. No tools this turn.`
    );
  }
  return (
    `In ${L}: From AVAILABLE DOCTORS in your instructions, pick ONE doctor whose specialty matches the visit reason. ` +
    `Tell the caller clearly: "इस समस्या के लिए Dr. [Name] ([specialty]) उपलब्ध हैं।" ` +
    `Then ask: "क्या मैं उनके पास appointment बुक करूँ?" ` +
    `Do NOT call create_appointment. Do NOT ask date/time yet. No tools this turn.`
  );
}

function getReadBackInstruction(lang) {
  const L = langLabel(lang);
  if (lang === "gu") {
    return (
      `In ${L}: Give ONE full booking read-back: name, visit reason, doctor name, date and time slot. ` +
      `End with: "શું બધું ઠીક છે?" Do NOT call any tool yet.`
    );
  }
  if (lang === "en") {
    return (
      `In ${L}: Give ONE full booking read-back: name, reason, doctor, date and time. ` +
      `End with: "Is everything correct?" Do NOT call tools yet.`
    );
  }
  return (
    `In ${L}: Give ONE full booking read-back in Hindi: name, visit reason, doctor name, date and time slot. ` +
    `End with: "क्या सब ठीक है?" Do NOT call any tool yet.`
  );
}

/**
 * Single-turn dispatch instructions for Sarvam+Realtime booking (toolChoice none unless step=book).
 * @param {{
 *   slots: import("./callBookingSlots").CallBookingSlots,
 *   rawUser: string,
 *   normalizedUser: string,
 *   preferredLanguage: 'hi'|'gu'|'en',
 * }} p
 */
function buildBookingDispatchInstructions(p) {
  const { slots, rawUser, normalizedUser, preferredLanguage } = p;
  const lang = preferredLanguage === "gu" ? "gu" : preferredLanguage === "en" ? "en" : "hi";
  const L = langLabel(lang);
  const step = getBookingFlowStep(slots, rawUser, normalizedUser);
  const caller = String(rawUser || "").trim();
  const spoken = getNextBookingSpokenQuestion(slots, lang);

  let body;
  if (step === "reason" || step === "name" || step === "age_gender" || step === "datetime") {
    body =
      `Caller said: "${caller || "(empty)"}". ` +
      `Ask ONLY the next missing field — do NOT skip ahead to doctor, date, or booking. ` +
      `Do NOT call any tool. Say in ${L}: "${spoken || "ask the next missing detail"}"`;
  } else if (step === "doctor") {
    body = `Caller said: "${caller}". ${getDoctorSuggestInstruction(lang)}`;
  } else if (step === "doctor_lock") {
    body =
      `Caller said: "${caller}" and confirmed the suggested doctor. ` +
      `Call list_doctors ONCE to lock the doctor reference internally, then ask ONLY for date and time in ${L}: "${getDateTimeQuestion(lang)}" ` +
      `Do NOT call create_appointment yet.`;
  } else if (step === "confirm") {
    body = `Caller said: "${caller}". ${getReadBackInstruction(lang)}`;
  } else if (step === "book") {
    return buildBookingTurnInstructions(p);
  } else {
    body = buildBookingTurnInstructions(p);
  }

  return [
    `BOOKING FLOW — ${L} only. Neha (female receptionist).`,
    `Missing fields (internal): ${getMissingBookingFields(slots).join(", ") || "none"}.`,
    "Do NOT call create_appointment until reason, name, age, gender, doctor, and date-time are all collected AND caller confirmed read-back.",
    body,
  ].join("\n");
}

/**
 * @param {import("./callBookingSlots").CallBookingSlots | null | undefined} slots
 * @returns {'name'|'age_gender'|'reason'|null}
 */
function getFirstMissingPatientField(slots) {
  if (!slots) return "reason";
  if (!String(slots.reason || "").trim()) return "reason";
  if (!String(slots.fullName || "").trim()) return "name";
  if (slots.age == null || !Number.isFinite(Number(slots.age))) return "age_gender";
  if (!String(slots.gender || "").trim()) return "age_gender";
  return null;
}

/**
 * Short label for no-input reprompt (Hindi / English / Gujarati).
 * @param {import("./callBookingSlots").CallBookingSlots | null | undefined} slots
 * @param {'hi'|'gu'|'en'} lang
 * @returns {string|null}
 */
function getNoInputMissingTopic(slots, lang) {
  const p = getFirstMissingPatientField(slots);
  if (p === "reason") {
    if (lang === "gu") return "તબિયત / મુલાકાતનું કારણ";
    if (lang === "en") return "reason for visit";
    return "तबीयत / विज़िट की वजह";
  }
  if (p === "name") {
    if (lang === "gu") return "નામ";
    if (lang === "en") return "full name";
    return "नाम";
  }
  if (p === "age_gender") {
    if (lang === "gu") return "ઉંમર અને લિંગ (male/female/other)";
    if (lang === "en") return "age and gender (male/female/other)";
    return "उम्र और लिंग (male/female/other)";
  }
  if (!String(slots?.doctorObjectId || "").trim()) {
    if (lang === "gu") return "ડૉક્ટર પસંદગી";
    if (lang === "en") return "doctor choice";
    return "डॉक्टर की पसंद";
  }
  if (!String(slots?.appointmentDateTimeISO || "").trim()) {
    if (lang === "gu") return "તારીખ અને સમય";
    if (lang === "en") return "date and time";
    return "तारीख और समय";
  }
  if (!isMongoObjectIdString(slots?.patientObjectId)) {
    if (lang === "gu") return "create_patient પછી patient._id";
    if (lang === "en") return "patient id after create_patient";
    return "create_patient के बाद patient._id";
  }
  return null;
}

function getVisitReasonQuestion(lang) {
  if (lang === "gu") {
    return "કૃપા કરીને જણાવો — તમે કેવી તકલીફ અથવા કયા લક્ષણ માટે ડૉક્ટરને મળવા માંગો છો?";
  }
  if (lang === "en") {
    return "Please tell me what symptoms or health issue you would like to see the doctor for.";
  }
  return "कृपया बताइए — किस तकलीफ या समस्या के लिए आप डॉक्टर से मिलना चाहेंगे?";
}

function getDateTimeQuestion(lang) {
  if (lang === "gu") {
    return "કૃપા કરીને જણાવો — તમે ક્યાં તારીખે અને કયા સમયે આવવા માંગો છો?";
  }
  if (lang === "en") {
    return "Which date and time slot would work for you?";
  }
  return "कृपया बताइए — आप किस तारीख और समय पर आना चाहेंगे?";
}

/**
 * Explicit spoken line for the next missing booking field (caller-facing).
 * @param {import("./callBookingSlots").CallBookingSlots} slots
 * @param {'hi'|'gu'|'en'} lang
 * @returns {string|null}
 */
function getNextBookingSpokenQuestion(slots, lang) {
  const l = lang === "gu" ? "gu" : lang === "en" ? "en" : "hi";
  const missing = getFirstMissingPatientField(slots);
  if (missing === "reason") return getVisitReasonQuestion(l);
  if (missing === "name") {
    if (l === "gu") return "કૃપા કરીને તમારું પૂરું નામ જણાવો.";
    if (l === "en") return "May I have your full name please?";
    return "कृपया अपना पूरा नाम बताइए।";
  }
  if (missing === "age_gender") {
    if (l === "gu") return "કૃપા કરીને ઉંમર અને લિંગ (male/female/other) જણાવો.";
    if (l === "en") return "Please tell me your age and gender (male, female, or other).";
    return "कृपया अपनी उम्र और लिंग (male/female/other) बताइए।";
  }
  if (!String(slots?.doctorObjectId || "").trim()) {
    if (l === "gu") {
      return "આ સમસ્યા માટે યોગ્ય ડૉક્ટર સજેસ્ટ કરો — નામ અને specialty બોલો, પછી appointment બુક કરવા પૂછો.";
    }
    if (l === "en") {
      return "Suggest the right doctor for this issue — say their name and specialty, then ask to book.";
    }
    return "इस समस्या के लिए सही डॉक्टर सुझाइए — नाम और specialty बताइए, फिर appointment बुक करने की permission लीजिए।";
  }
  if (!String(slots?.appointmentDateTimeISO || "").trim()) {
    return getDateTimeQuestion(l);
  }
  return null;
}

/**
 * First line after caller chooses normal (non-emergency) case.
 * @param {'hi'|'gu'|'en'} lang
 */
function getBookingKickoffInstructions(lang) {
  const langLabel =
    lang === "gu" ? "Gujarati" : lang === "en" ? "English" : "Hindi";
  const q = getVisitReasonQuestion(lang);
  return (
    `The caller chose NORMAL case (not emergency). In ${langLabel}, give ONE brief acknowledgment (e.g. ठीक है / સમજાય ગયું), ` +
    `then ask EXACTLY this visit-reason question and STOP — do NOT ask name, doctor, date, or time yet:\n"${q}"`
  );
}

/**
 * Compact captured-slots summary for INTERNAL LLM reasoning only.
 * Uses neutral labels (no leak-prone tool / DB field names) and is wrapped by the
 * caller in a "do NOT read aloud" banner. Keep the references; the model needs
 * them to fill the right tool arguments — just never to speak them.
 *
 * @param {import("./callBookingSlots").CallBookingSlots} slots
 */
function formatSlotSnapshot(slots) {
  const parts = [];
  if (slots.fullName) parts.push(`patient-name=${slots.fullName}`);
  if (slots.age != null && Number.isFinite(Number(slots.age)))
    parts.push(`patient-age=${slots.age}`);
  if (slots.gender) parts.push(`patient-gender=${slots.gender}`);
  if (slots.reason)
    parts.push(`visit-reason-raw=${String(slots.reason).slice(0, 120)}`);
  if (slots.firstVisit === true) parts.push("first-visit=yes");
  if (slots.firstVisit === false) parts.push("first-visit=no");
  if (slots.pendingDateYmd)
    parts.push(`pending-date-ist=${slots.pendingDateYmd}`);
  if (slots.appointmentDateTimeISO)
    parts.push(`appointment-datetime-ist=${slots.appointmentDateTimeISO}`);
  if (slots.doctorObjectId)
    parts.push(`doctor-ref=${slots.doctorObjectId}`);
  if (isMongoObjectIdString(slots.patientObjectId))
    parts.push(`patient-ref=${slots.patientObjectId}`);
  else
    parts.push(
      "patient-ref=(not yet registered this call — silently register the patient before creating the appointment)",
    );
  if (slots.appointmentObjectId)
    parts.push(`appointment-ref=${slots.appointmentObjectId}`);
  return parts.length
    ? parts.join("; ")
    : "(nothing captured yet)";
}

/**
 * Per-response instructions for OpenAI Realtime (high priority for this turn only).
 * @param {{
 *   slots: import("./callBookingSlots").CallBookingSlots,
 *   rawUser: string,
 *   normalizedUser: string,
 *   preferredLanguage: 'hi'|'gu'|'en',
 * }} p
 */
function buildBookingTurnInstructions(p) {
  const { slots, rawUser, normalizedUser, preferredLanguage } = p;
  const lang =
    preferredLanguage === "gu"
      ? "Gujarati"
      : preferredLanguage === "en"
        ? "English"
        : "Hindi";
  const snapshot = formatSlotSnapshot(slots);
  const missingPatient = getFirstMissingPatientField(slots);
  const hasPatient =
    !missingPatient &&
    String(slots.reason || "").trim().length > 0;
  const hasIso = String(slots.appointmentDateTimeISO || "").trim().length > 0;
  const hasDoctor = String(slots.doctorObjectId || "").trim().length > 0;
  const hasPatientOid = isMongoObjectIdString(slots.patientObjectId);

  const affirm = isAffirmativeTurn(rawUser, normalizedUser);
  const spokenNext = getNextBookingSpokenQuestion(slots, preferredLanguage);

  let action;
  if (missingPatient) {
    action = `Internal-next-turn: ask for ONLY the first missing patient field (${missingPatient}) in one short ${lang} question. Do NOT read back the full booking block. Acknowledge briefly if needed.`;
  } else if (!hasDoctor) {
    action = `Internal-next-turn: the patient info (reason, name, age, gender) is complete. Now suggest a doctor from the AVAILABLE DOCTORS list whose specialty matches the visit reason — say one short ${lang} line like "इसके लिए Dr. [name] के पास समय बुक कर सकती हूँ।" and lock that doctor. Do NOT call list_doctors if the doctor is already in the system prompt list.`;
  } else if (!hasIso) {
    action = `Internal-next-turn: doctor is chosen. Now ask for ONLY date and time slot (one short ${lang} question). Ask date first if not given, then time slot.`;
  } else if (affirm && hasPatient && hasIso && hasDoctor && isBookingReadyForCreateAppointment(slots)) {
    const gate =
      "If you have NOT yet done the single read-back for this booking, do it once in " +
      lang +
      " before any tools; if you already did and the caller confirmed, do not read the full block again.";
    if (!hasPatientOid) {
      action = `Tool-now: ${gate} Internal recovery order — first register the patient (name + age + gender + English reason), wait for success, then create the appointment using the freshly returned patient reference (never use age, "1", or the human patient number). Speak only the short wait line in ${lang}. If an appointment was already booked earlier in this same call, the next create-appointment call updates that same booking automatically — never mention numbers or IDs aloud.`;
    } else {
      action = `Tool-now: ${gate} Speak the short wait line in ${lang}, then create the appointment with the doctor reference, valid patient reference, English reason, and IST date-time. If an earlier appointment exists in this call and the caller is changing details, that booking is updated automatically.`;
    }
  } else if (affirm && hasPatient && hasIso && hasDoctor) {
    action =
      "The caller said YES but booking prerequisites may be incomplete — do NOT call create_appointment yet; ask for any missing detail first.";
  } else if (affirm && isBookingReadyForCreateAppointment(slots) && !hasIso) {
    action = `Ask for date and time in ${lang} before any booking tools.`;
  } else if (affirm) {
    action = `The caller said YES — complete the booking silently without a second full read-back if the read-back was already done; otherwise do exactly one read-back block.`;
  } else {
    action = `Internal-next-turn: continue efficiently in ${lang}; one new ask or one read-back only when prerequisites are met; never repeat the same summary twice after the caller has already agreed.`;
  }

  return [
    "INTERNAL_TURN_NOTES — for your reasoning only. NEVER read, translate, or paraphrase any of these notes, field names, or English status words aloud. The caller-facing reply must be ONLY natural " +
      lang +
      " (no English variable names, tool names, MongoDB/ID/JSON terms, or status words like ok/true/false/null — see the hard-banned list in the main system prompt).",
    preferredLanguage === "hi"
      ? "LANGUAGE_LOCK: Caller chose Hindi for this call. Every word you speak aloud must be Hindi — no English sentence openers (Great, Understood, Okay, Sure, Please, Thank you) and no English questions; use ठीक है, समझ गई, जी, कृपया, धन्यवाद, etc. Latin names (Hardik, Sarvodaya) are allowed as names only."
      : preferredLanguage === "gu"
        ? "LANGUAGE_LOCK: Caller chose Gujarati for this call. Every word you speak aloud must be Gujarati — use સમજાય ગયું, જી, કૃપા કરીને, આભાર, etc. Latin names are allowed as names only."
        : preferredLanguage === "en"
          ? "LANGUAGE_LOCK: Caller chose English for this call. Speak only clear Indian English — do not switch to Hindi or Gujarati sentences mid-turn unless the caller explicitly asks to switch."
          : "",
    isMongoObjectIdString(slots?.doctorObjectId)
      ? "Doctor is already chosen — use captured doctor-ref as doctorObjectId. Do NOT call list_doctors."
      : "",
    "Captured slots so far (internal — do NOT read aloud):",
    snapshot,
    "Action plan (internal — do NOT read aloud):",
    action,
    spokenNext
      ? `Caller-facing line (say this in ${lang} — exact wording or very close): "${spokenNext}"`
      : "",
    `Caller's locked language: ${lang}. Reply entirely in ${lang} (sorry line, wait line, fillers) even if the caller mixed a few English words.`,
  ]
    .filter(Boolean)
    .join("\n");
}

module.exports = {
  buildBookingTurnInstructions,
  buildBookingDispatchInstructions,
  getBookingFlowStep,
  getMissingBookingFields,
  isBookingReadyForCreateAppointment,
  isBookingReadyForCreatePatient,
  getFirstMissingPatientField,
  getNoInputMissingTopic,
  formatSlotSnapshot,
  getVisitReasonQuestion,
  getDateTimeQuestion,
  getNextBookingSpokenQuestion,
  getBookingKickoffInstructions,
};
